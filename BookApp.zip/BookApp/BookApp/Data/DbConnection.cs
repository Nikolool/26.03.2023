﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BookApp.Data
{
    public class DbConnection1
    {
        //private SqlConnection dbCon;
        //public void CreateConnection()
        //{
        //    dbCon = new SqlConnection("Server=.\\SQLEXPRESS; Database=ItKariera; Integrated Security=true");
        //}
    }
}
